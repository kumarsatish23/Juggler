## libpng v1.6.43

### libpng License
<pre>

COPYRIGHT NOTICE, DISCLAIMER, and LICENSE
=========================================

PNG Reference Library License version 2
---------------------------------------

Copyright (C) 1995-2024 The PNG Reference Library Authors.
Copyright (C) 2018-2024 Cosmin Truta
Copyright (C) 1998-2018 Glenn Randers-Pehrson
Copyright (C) 1996-1997 Andreas Dilger
Copyright (C) 1995-1996 Guy Eric Schalnat, Group 42, Inc.

The software is supplied "as is", without warranty of any kind,
express or implied, including, without limitation, the warranties
of merchantability, fitness for a particular purpose, title, and
non-infringement.  In no event shall the Copyright owners, or
anyone distributing the software, be liable for any damages or
other liability, whether in contract, tort or otherwise, arising
from, out of, or in connection with the software, or the use or
other dealings in the software, even if advised of the possibility
of such damage.

Permission is hereby granted to use, copy, modify, and distribute
this software, or portions hereof, for any purpose, without fee,
subject to the following restrictions:

 1. The origin of this software must not be misrepresented; you
    must not claim that you wrote the original software.  If you
    use this software in a product, an acknowledgment in the product
    documentation would be appreciated, but is not required.

 2. Altered source versions must be plainly marked as such, and must
    not be misrepresented as being the original software.

 3. This Copyright notice may not be removed or altered from any
    source or altered source distribution.


PNG Reference Library License version 1 (for libpng 0.5 through 1.6.35)
-----------------------------------------------------------------------

libpng versions 1.0.7, July 1, 2000, through 1.6.35, July 15, 2018 are
Copyright (c) 2000-2002, 2004, 2006-2018 Glenn Randers-Pehrson, are
derived from libpng-1.0.6, and are distributed according to the same
disclaimer and license as libpng-1.0.6 with the following individuals
added to the list of Contributing Authors:

    Simon-Pierre Cadieux
    Eric S. Raymond
    Mans Rullgard
    Cosmin Truta
    Gilles Vollant
    James Yu
    Mandar Sahastrabuddhe
    Google Inc.
    Vadim Barkov

and with the following additions to the disclaimer:

    There is no warranty against interference with your enjoyment of
    the library or against infringement.  There is no warranty that our
    efforts or the library will fulfill any of your particular purposes
    or needs.  This library is provided with all faults, and the entire
    risk of satisfactory quality, performance, accuracy, and effort is
    with the user.

Some files in the "contrib" directory and some configure-generated
files that are distributed with libpng have other copyright owners, and
are released under other open source licenses.

libpng versions 0.97, January 1998, through 1.0.6, March 20, 2000, are
Copyright (c) 1998-2000 Glenn Randers-Pehrson, are derived from
libpng-0.96, and are distributed according to the same disclaimer and
license as libpng-0.96, with the following individuals added to the
list of Contributing Authors:

    Tom Lane
    Glenn Randers-Pehrson
    Willem van Schaik

libpng versions 0.89, June 1996, through 0.96, May 1997, are
Copyright (c) 1996-1997 Andreas Dilger, are derived from libpng-0.88,
and are distributed according to the same disclaimer and license as
libpng-0.88, with the following individuals added to the list of
Contributing Authors:

    John Bowler
    Kevin Bracey
    Sam Bushell
    Magnus Holmgren
    Greg Roelofs
    Tom Tanner

Some files in the "scripts" directory have other copyright owners,
but are released under this license.

libpng versions 0.5, May 1995, through 0.88, January 1996, are
Copyright (c) 1995-1996 Guy Eric Schalnat, Group 42, Inc.

For the purposes of this copyright and license, "Contributing Authors"
is defined as the following set of individuals:

    Andreas Dilger
    Dave Martindale
    Guy Eric Schalnat
    Paul Schmidt
    Tim Wegner

The PNG Reference Library is supplied "AS IS".  The Contributing
Authors and Group 42, Inc. disclaim all warranties, expressed or
implied, including, without limitation, the warranties of
merchantability and of fitness for any purpose.  The Contributing
Authors and Group 42, Inc. assume no liability for direct, indirect,
incidental, special, exemplary, or consequential damages, which may
result from the use of the PNG Reference Library, even if advised of
the possibility of such damage.

Permission is hereby granted to use, copy, modify, and distribute this
source code, or portions hereof, for any purpose, without fee, subject
to the following restrictions:

 1. The origin of this source code must not be misrepresented.

 2. Altered versions must be plainly marked as such and must not
    be misrepresented as being the original source.

 3. This Copyright notice may not be removed or altered from any
    source or altered source distribution.

The Contributing Authors and Group 42, Inc. specifically permit,
without fee, and encourage the use of this source code as a component
to supporting the PNG file format in commercial products.  If you use
this source code in a product, acknowledgment is not required but would
be appreciated.

TRADEMARK
=========

The name "libpng" has not been registered by the Copyright owners
as a trademark in any jurisdiction.  However, because libpng has
been distributed and maintained world-wide, continually since 1995,
the Copyright owners claim "common-law trademark protection" in any
jurisdiction where common-law trademark is recognized.

</pre>

### AUTHORS File Information
```
PNG REFERENCE LIBRARY AUTHORS
=============================

This is the list of PNG Reference Library ("libpng") Contributing
Authors, for copyright and licensing purposes.

 * Adam Richter
 * Andreas Dilger
 * Chris Blume
 * Cosmin Truta
 * Dave Martindale
 * Eric S. Raymond
 * Gilles Vollant
 * Glenn Randers-Pehrson
 * Greg Roelofs
 * Guy Eric Schalnat
 * James Yu
 * John Bowler
 * Kevin Bracey
 * Magnus Holmgren
 * Mandar Sahastrabuddhe
 * Mans Rullgard
 * Matt Sarett
 * Mike Klein
 * Pascal Massimino
 * Paul Schmidt
 * Philippe Antoine
 * Qiang Zhou
 * Sam Bushell
 * Samuel Williams
 * Simon-Pierre Cadieux
 * Tim Wegner
 * Tom Lane
 * Tom Tanner
 * Vadim Barkov
 * Willem van Schaik
 * Zhijie Liang
 * Apple Inc.
    - Zixu Wang (王子旭)
 * Arm Holdings
    - Richard Townsend
 * Google Inc.
    - Dan Field
    - Leon Scroggins III
    - Matt Sarett
    - Mike Klein
    - Sami Boukortt
    - Wan-Teh Chang
 * Loongson Technology Corporation Ltd.
    - GuXiWei (顾希伟)
    - JinBo (金波)
    - ZhangLixia (张利霞)

The build projects, the build scripts, the test scripts, and other
files in the "projects", "scripts" and "tests" directories, have
other copyright owners, but are released under the libpng license.

Some files in the "ci" and "contrib" directories, as well as some
of the tools-generated files that are distributed with libpng, have
other copyright owners, and are released under other open source
licenses.
```
